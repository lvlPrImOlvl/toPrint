/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplolinkedlist;
//import java.util.*;

import java.util.LinkedList;

/**
 *
 * @author cur01alu12
 */
public class EjemploLinkedList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LinkedList<String> nombres = new LinkedList<String>();
        nombres.add("Juan");
        nombres.add("Maria");
        nombres.add("Pedro");
        nombres.add("Mary");
        nombres.addFirst("Elena");
        nombres.addLast("Guadalupe");
        nombres.add(2,"German");
        
        System.out.println("Contenido: " + nombres);
        System.out.println("Metodo getFirst(): " + nombres.getFirst());
        System.out.println("Metodo getLast(): " + nombres.getLast());
        //Peek -> Muestra pero no eloimina el primer elemento
        System.out.println("Metodo peek(): " + nombres.peek());
        System.out.println("Contenido: " + nombres);
        //Poll -> Muestra y elimina
        System.out.println("Hacemos poll(): " + nombres.poll());
        System.out.println("Contenido: " + nombres);
        System.out.println("Hacemos poll(): " + nombres.poll());
        System.out.println("Contenido: " + nombres);
        
    }
    
}

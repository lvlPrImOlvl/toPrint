//Autor Eduardo Castro Garcia
import java.io.Serializable;
public class Vuelo implements Serializable{
	private String destino;
	private String horaSalida;
	private String horaLlegada;
	private String fechaSalida;
	private double costoTurista;
	private double costoPrimera;
	private int lugaresTurista;
	private int lugaresPrimera;

	public Vuelo(String destino,String horaSalida,String horaLlegada,String fechaSalida, double costoTurista, double costoPrimera, int lugaresTurista, int lugaresPrimera){

		this.destino = destino;
		this.horaSalida = horaSalida;
		this.horaLlegada = horaLlegada;
		this.fechaSalida = fechaSalida;
		this.costoTurista =costoTurista;
		this.costoPrimera= costoPrimera;
		this.lugaresTurista = lugaresTurista;
		this.lugaresPrimera = lugaresPrimera;
	}

	@Override
	public String toString(){
		return "Destino: "+ this.destino + "\nHora de salida: "+ this.horaSalida + "\nHora de llegada: "+ this.horaLlegada + "\nFecha de salida: "+ this.fechaSalida + "\nCosto turista: "+ this.costoTurista + "\nCosto primera: "+ this.costoPrimera + "\nLugares turista: "+ this.lugaresTurista + "\nLugares primera: "+ this.lugaresPrimera;
	}


	//seterss
	public void setDestino(String destino){
		this.destino = destino;
	}

	public void setHoraSalida(String horaSalida){
		this.horaSalida = horaSalida;
	}

	public void setHoraLlegada(String  horaLlegada){
		this.horaLlegada = horaLlegada;
	}

	public void setFechaSalida(String fechaSalida){
		this.fechaSalida = fechaSalida;
	}

	public void setCostoTurista(double costoTurista){
		this.costoTurista = costoTurista;
	}

	public void setCostoPrimera(double costoPrimera){
		this.costoPrimera = costoPrimera;
	}

	public void setLugaresTurista(int lugaresTurista){
		this.lugaresTurista = lugaresTurista;
	}

	public void setLugaresPrimera(int lugaresPrimera){
		this.lugaresPrimera = lugaresPrimera;
	}



	//geterss
	public String getDestino(){
		return this.destino;
	}

	public String getHoraSalida(){
		return this.horaSalida;
	}

	public String getHoraLlegada(){
		return this.horaLlegada;
	}

	public String getFechaSalida(){
		return this.fechaSalida;
	}

	public double getCostoTurista(){
		return this.costoTurista;
	}

	public double getCostoPrimera(){
		return this.costoPrimera;
	}

	public int getLugaresTurista(){
		return this.lugaresTurista;
	}

	public int getLugaresPrimera(){
		return this.lugaresPrimera;
	}
}
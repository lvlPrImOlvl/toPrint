//Autor Eduardo Castro Garcia

import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.File;
public class Aerolinea{

	static ArrayList<Vuelo> vuelos = new ArrayList<Vuelo>();
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

        FileOutputStream fos = null;
        ObjectOutputStream salida = null;

        try
        {
            fos = new FileOutputStream("./vuelos.dat");
            salida = new ObjectOutputStream(fos); 
        } catch (FileNotFoundException e) {
            System.out.println("1"+e.getMessage());
        } catch (IOException e) {
            System.out.println("2"+e.getMessage());
        } finally {
            try {
                if(fos!=null) fos.close();
                if(salida!=null) salida.close();
            } catch (IOException e) {
                System.out.println("3"+e.getMessage());
            }
        }

		int opcion = 0;
		
		do{
			System.out.println("1. Administrador\n2. Cliente\n3.Salir");
			opcion = sc.nextInt();
			sc.nextLine();

			switch(opcion){
				

				/*
				////////////////////////////////
				Inicio del case uno Administrador
				/////////////////////////////////
				*/
				case 1:
					int opcion2 = 0;
					System.out.println("Bienvenido Administrador");

					System.out.println("\nLA CONTRASENA ES: casgar\n");

					System.out.println("Ingrese contrasena de administrador");
					String contrasena = sc.nextLine();

					if(contrasena.equals("casgar")){

						do{

							int i=1,borrar = 0;
							System.out.println("\t1. Alta\n\t2. Baja\n\t3. Editar\n\t4. Ver\n\t5. Guardar 6. Regresar");
							opcion2 = sc.nextInt();

							switch(opcion2){
								case 1:

 	 								System.out.print("\n\tIngresa el destino: ");
									String destino = sc.nextLine();
									destino = sc.nextLine();
									
									
									System.out.print("\tHora de salida: ");
									String horaSalida = sc.nextLine();
									
									System.out.print("\tHora de llegada: ");
									String horaLlegada = sc.nextLine();

									System.out.print("\tFecha salida: ");
									String fechaSalida = sc.nextLine();
								
									System.out.print("\tCosto turista: ");
									double costoTurista = sc.nextDouble();
								
									System.out.print("\tCosto primera: ");
									double costoPrimera = sc.nextDouble();

									System.out.print("\tLugares turista: ");
									int lugaresTurista = sc.nextInt();
								
									System.out.print("\tLugares primera: ");
									int lugaresPrimera = sc.nextInt();

									Vuelo v = new Vuelo(destino,horaSalida,horaLlegada,fechaSalida,costoTurista,costoPrimera,lugaresTurista,lugaresPrimera);

									System.out.println(v);

									vuelos.add(v);
									try
									{
										salida.writeObject(v);
									}
									catch(Exception e){}
								break;
								
								case 2:
									//Que muestre todos los vuelos con los indice
									for (Vuelo elemento : vuelos ) {
										System.out.printf("\n\nVuelo %d:\n",i);
										System.out.println(elemento);
										i++;
									}
									System.out.println("Introduce el vuelo que quieres borrar");
									borrar = sc.nextInt();
									//Pasar la variable al metodo remove  
									vuelos.remove(borrar-1);
									//Se a eliminado correctamente
									System.out.printf("Vuelo %d se a borrado correctamente\n",borrar);

								break;

								case 3:
									//Que muestre todos los vuelos con los indice
									for (Vuelo elemento : vuelos ) {
										System.out.printf("\n\nVuelo %d:\n",i);
										System.out.println(elemento);
										i++;
									}

										System.out.println("Introduce el vuelo que quieres editar");
										borrar = sc.nextInt();
										//Muestre un menu donde pueda ver los atributos a editar
										int opcion3;
									
										System.out.println("Que atributo quieres cambiar");
										System.out.println("1. Destino\n2. Hora de salida\n3. Hora de llegada\n4. Fecha de salida\n5. Costo turista\n6. Costo primera\n7. Lugares turista\n8. Lugares primera\n9. Regresar");
										opcion3 = sc.nextInt();
										//Acceder el arreglo en el indice seleccionado
										switch (opcion3) {
											case 1:
												System.out.println("Introduce el nuevo destino");
												String nuevoDestino = sc.nextLine();
												nuevoDestino = sc.nextLine();
												borrar -= 1;
												vuelos.get(borrar).setDestino(nuevoDestino);

												System.out.println("El cambio del destino a sido un exito: \n"+vuelos.get(borrar));
																										 
											break;
											
											case 2:
												
												System.out.println("Introduce la nueva hora de salida");
												String nuevaHoraSalida = sc.nextLine();
												nuevaHoraSalida = sc.nextLine();
												borrar -= 1;
												vuelos.get(borrar).setHoraSalida(nuevaHoraSalida);

												System.out.println("El cambio del destino a sido un exito: \n"+vuelos.get(borrar));

											break;

											case 3:

												System.out.println("Introduce la nueva hora de llegada");
												String nuevaHoraLlegada = sc.nextLine();
												nuevaHoraLlegada = sc.nextLine();
												borrar -= 1;
												vuelos.get(borrar).setHoraLlegada(nuevaHoraLlegada);

												System.out.println("El cambio del destino a sido un exito: \n"+vuelos.get(borrar));

											break;

											case 4:

												System.out.println("Introduce la nueva fecha de salida");
												String nuevaFechaSalida = sc.nextLine();
												nuevaFechaSalida = sc.nextLine();
												borrar -= 1;
												vuelos.get(borrar).setFechaSalida(nuevaFechaSalida);

												System.out.println("El cambio del destino a sido un exito: \n"+vuelos.get(borrar));

											break;

											case 5:

												System.out.println("Introduce el nuevo costo de los boletos de turistas");
												double nuevaCostoTurista = sc.nextDouble();
												//nuevaCostoTurista = sc.nextDouble();
												borrar -= 1;
												vuelos.get(borrar).setCostoTurista(nuevaCostoTurista);

												System.out.println("El cambio del destino a sido un exito: \n"+vuelos.get(borrar));


											break;

											case 6:

												System.out.println("Introduce el nuevo costo de los boletos de primera");
												double nuevaCostoPrimera = sc.nextDouble();
												//nuevaCostoPrimera = sc.nextDouble();
												borrar -= 1;
												vuelos.get(borrar).setCostoPrimera(nuevaCostoPrimera);

												System.out.println("El cambio del destino a sido un exito: \n"+vuelos.get(borrar));

											break;

											case 7:

												System.out.println("Introduce la nueva cantidad de lugares de la clase turista ");
												int nuevaLugaresTurista = sc.nextInt();
												//nuevaLugaresTurista = sc.nextInt();
												borrar -= 1;
												vuelos.get(borrar).setLugaresTurista(nuevaLugaresTurista);

												System.out.println("El cambio del destino a sido un exito: \n"+vuelos.get(borrar));

											break;

											case 8:

												System.out.println("Introduce la nueva cantidad de lugares de la clase primera ");
												int nuevaLugaresPrimera = sc.nextInt();
												//nuevaLugaresPrimera = sc.nextInt();
												borrar -= 1;
												vuelos.get(borrar).setLugaresPrimera(nuevaLugaresPrimera);

												System.out.println("El cambio del destino a sido un exito: \n"+vuelos.get(borrar));

											break;


											case 9:

											break;
				
											default:

												System.out.println("Error elige una obcion valida");

											break;
										}							
								break;

								case 4:

								///
								ObjectInputStream ois = null;
try {
	File f = new File ("./vuelos.dat");
	FileInputStream ficheroEntrada = new FileInputStream(f);
	ObjectInputStream objetoEntrada = new ObjectInputStream(ficheroEntrada);
	System.out.println("Datos");
	while (true)
	{
		try
		{
			Vuelo p1 = (Vuelo)objetoEntrada.readObject();
		System.out.println(p1.toString());
		}
		catch (Exception e) {
System.out.println(e.getMessage());
}
	}
}
catch (IOException e) {
System.out.println(e.getMessage());
}
								///
									i=1;
									for (Vuelo elemento : vuelos ) {
										System.out.printf("\n\nVuelo %d:\n",i);
										System.out.println(elemento);
										i++;
									}
								break;

								case 5:
								System.out.println("#S");
								break;

								case 6:
									System.out.println("Nos vemos  " + contrasena );
								break;
							}
						}while(opcion2 != 5);
					}
					else{
						System.out.println("Contrasena no valida");
					}	
				break;
				
				/*/////////////////////////
				Inicio del case dos Cliente
				//////////////////////////*/

				case 2:
					//ver los vuelos
					//comprar los vuelos
					int opci2;
					System.out.println("1. Ver los vuelos\n2. Comprar vuelos\n3.Salir");
					opci2 = sc.nextInt();
					sc.nextLine();

					switch(opci2){

						case 1:

							int i=1;
							for (Vuelo elemento : vuelos ) {
								System.out.printf("\n\nVuelo %d:\n",i);
								System.out.println(elemento);
								i++;
							}

						break;

						case 2:
							int vue,opci3,res,cantidad,opci4;
							String nom;

							System.out.println("Ingresa nombre");
							nom = sc.nextLine();
							
//
								System.out.println("Ingresa el vuelo");
								vue = sc.nextInt();

								vue -= 1;

								System.out.println(vuelos.get(vue));

								System.out.println("1. Deseas comprar voletos para este vuelo\n2. Comprar otro vuelo\n3. No");
								opci3 = sc.nextInt();
							
								switch(opci3) {

									case 1:
										
										System.out.println("Introduce el tipo de boleto a escoger\n1. Clase turista\n2. Clase primera");
										opci4 = sc.nextInt();

										switch(opci4){

											case 1:

												System.out.println("Precio por boleto: " + vuelos.get(vue).getCostoTurista());

												System.out.println("Ingresa la cantidad de boletos");
												cantidad = sc.nextInt();

												res = vuelos.get(vue).getLugaresTurista();
												res -= cantidad;

												vuelos.get(vue).setLugaresTurista(res);

												System.out.println( vuelos.get(vue));

												System.out.println("La operacion a sido un exito");

											break;

											case 2:

												System.out.println("Precio por boleto: " + vuelos.get(vue).getCostoPrimera());

												System.out.println("Ingresa la cantidad de boletos");
												cantidad = sc.nextInt();

												res = vuelos.get(vue).getLugaresPrimera();
												res -= cantidad;

												vuelos.get(vue).setLugaresPrimera(res);

												System.out.println( vuelos.get(vue));

												System.out.println("La operacion a sido un exito " + nom);

											break;

											default:
											System.out.println("Error");

											break;
										}

									break;

									case 2:

									break;

									case 3:

										System.out.println("Gracias por su compra " + nom);

									break;
								}
						break;

						case 3:

							System.out.println("Gracias lo esperamos pronto");
							
						break;

						default:

						System.out.println("Error");

						break;

					}
					
				break;
				
				case 3:

					System.out.println("Gracias por su visita");

				break;
				
				default:

					System.out.println("Error");

				break;
			}
		}while(opcion != 3);
	}

}
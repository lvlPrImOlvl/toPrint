package ejemplohashmap;

import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class EjemploHashMap {

    public static void main(String[] args) {
       Map<Integer, String> map = new HashMap<Integer, String>();
       map.put(1, "Casillas");
       map.put(15,"ramos");
       map.put(3, "Pique");
       map.put(5, "Jorge");
       map.put(11, "Marisol");
       map.put(14, "Viridiana");
       map.put(16,"Basquet");
       
       //Iterador
       Iterator  it = map.keySet().iterator();
       Integer key;
       while (it.hasNext())
       {
           key= (Integer) it.next();
           System.out.println("Clave: " + key + " -> Valor: " +map.get(key));
       }
       
       System.out.println("****Metodos de Map****\n");
       System.out.println("Mostramos el numero de elementos que tiene el Map: " 
               + map.size());
       System.out.println("Verificamos si el map esta vacio: " + map.isEmpty());
       System.out.println("Obtenemos el elemento de la llave 3 del Map: " + map.get(3));
       System.out.println("Borramos el elemento de la llave 3 del Map: " +map.remove(3));
       System.out.println("Verificamos que ya no estan el elemento: \n" + map); 
       System.out.println("Checamos si el map contiene una llave:" + map.containsKey(1));
       System.out.println("Checamos si el map contiene un valor:" + map.containsValue("Jorge"));
       System.out.println("Limpiamos el map con clear():");
       map.clear();
       System.out.println("Verificamos el numero de elementos de map: " + map.size());
    }
    
}

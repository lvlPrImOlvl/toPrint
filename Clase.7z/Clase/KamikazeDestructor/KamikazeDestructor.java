package KamikazeDestructor;
import robocode.*;
import java.awt.Color;

/**Esta clase hereda de un robot avanzado, para poder utilizar ciertas funciones*/
public class KamikazeDestructor extends AdvancedRobot
{
	double apuntar;
	double fixedAngle;
	public void run() 
	{
	//	Sets the color of the robot's body, gun, radar, bullet, and scan arc in the same time. 
		setColors(Color.black,Color.red,Color.yellow, Color.yellow, Color.red); // body,gun,radar
		//Comportamiento del robot
		while(true) 
		{
		ahead(100);
		turnGunRight(360);
		}
	}

/** Este metodo detecta a un robot rival
  * @param e Objeto tipo ScannedRobotEvent para poder detectar al robot
  * @see setAhead()
  * @see setTurnRight()
  * @see getDistance()
  * @see getBearing()
  * @see normalRelativeAngle()
  * @see getGunHeading()
  * @see turnGunRight()
  * @see disparoInteligente(ScannedRobotEvent)
*/
	public void onScannedRobot(ScannedRobotEvent e)
	{
		setAhead(e.getDistance());
		setTurnRight(e.getBearing());
		// getheading regresa la orientacion del robot ( 0 a 360)
		// e.getBearing regresa la orientacion del robot enemigo, con respecto a nosotros (-180 a - 180)
		// getGunHeading regresa la orientacion del cañon ( 0 a 360)
		apuntar = normalRelativeAngle(getHeading() + e.getBearing() - getGunHeading());
		turnGunRight(apuntar);
		disparoInteligente(e);
	}

/** Este metodo detecta el momento en que nos impactan con una bala
  * @param e Objeto tipo HitByBulletEvent para poder detectar el impacto
  * @see normalRelativeAngle()
*/
    public void onHitByBullet(HitByBulletEvent e)
	{
    	apuntar = normalRelativeAngle(e.getBearing() + getHeading() - getGunHeading());
	    turnGunRight(apuntar);
		scan();
    }
	
/** Este metodo detecta el momento en que chocamos con una pared
  * @param e Objeto tipo HitWallEvent para poder detectar el choque
  * @see scan()
*/
	public void onHitWall(HitWallEvent e)
	{
	scan();
	}

/** Este metodo detecta el momento en que chocamos con un robot
  * @param e Objeto tipo HitRobotEvent para poder detectar el choque
  * @see scan
*/
    public void onHitRobot(HitRobotEvent e)
	{
	scan();
    }	

/** Metodo para normalizar un angulo relativo, se necesita para determinar a donde dirigirse o apuntar tras
  * detectar a un oponente o impacto
  * @param angle Angulo a normalizar
  * @return angle Regresa el mismo angulo si no hubo que procesarlo
  * @return fixedAngle Angulo modificado para poder ocuparlo
*/
	public double normalRelativeAngle(double angle)
	{
        if (angle > -180 && angle <= 180)
     		return angle;
        fixedAngle = angle;
        while (fixedAngle <= -180)
        	fixedAngle += 360;
        while (fixedAngle > 180)
       	 	fixedAngle -= 360;
        return fixedAngle;
    }

/** Este metodo varia la poten cia de disparo dependiendo la distancia del adversario
  * @param e Objeto tipo ScannedRobotEvent para poder utilizar el metodo getDistance
*/
	public void disparoInteligente(ScannedRobotEvent e)
	{
		if (e.getDistance() < 100)
		{
		setFire (3);
		}
		else if (e.getDistance() < 200 )
		{
		setFire (2);
		}
		else
		setFire (1);
	}

/** Este metodo realiza una maniobra cuando gana la batalla
  * @param e Objeto tipo WinEvent para poder detectar el final de la batalla
*/
	public void onWin(WinEvent e) 
	{
            setTurnRight(360);
            setTurnGunLeft(360);
            execute();
	}
}